function kiszamolo() {
    const adatBevitel = document.getElementById("ID-AdatBevitel").value,
        adatMennyisegMértékegysége = document.getElementById("ID-AdatBeviteliMértékegység").value,
        átviteliMennyiség = document.getElementById("ID-AdatSebessége").value,
        átviteliSebessegMértékegysége = document.getElementById("ID-AdatSebességnekMértékegysége").value,
        átviteliIdő = document.getElementById("ID-Átviteliidő");
        var elsőinputértéke = 0;
        var másodikinputértéke = 0;

    if (adatMennyisegMértékegysége == "TB") {
        elsőinputértéke = adatBevitel * 1000000

    }
    else if (adatMennyisegMértékegysége == "GB") {
        elsőinputértéke= adatBevitel * 1000

    }
    else if (adatMennyisegMértékegysége == "MB") {
        elsőinputértéke = adatBevitel 

    }

    else if (adatMennyisegMértékegysége == "KB") {
        elsőinputértéke= adatBevitel / 1000

    }

   
   
   
   
   
    if (átviteliSebessegMértékegysége == "TB/s") {
        másodikinputértéke = átviteliMennyiség * 1000000

    }
    else if (átviteliSebessegMértékegysége == "GB/s") {
        másodikinputértéke = átviteliMennyiség * 1000

    }

    else if (átviteliSebessegMértékegysége == "MB/s") {
        másodikinputértéke = átviteliMennyiség 

    }

    else if (átviteliSebessegMértékegysége == "KB/s") {
        másodikinputértéke = átviteliMennyiség / 1000

    }
    
    átviteliIdő.textContent = elsőinputértéke/másodikinputértéke;


}


function csuszkaertek() {
    let ertek = document.getElementById("ID-AdatSebessége").value;
    let ertekmegjelenítő = document.getElementById("ID-AdatSebességspan");

    ertekmegjelenítő.textContent = ertek;



}